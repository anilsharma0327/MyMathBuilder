import java.util.Scanner;
class CommonDivisor
{ 
	
	static int GCD(int a, int b) 
	{ 
		if (a == 0) 
		           return b; 
  
 		return GCD(b % a, a); 
 	} 
	static int commDiv(int a, int b) 
	{ 
		
		int n = GCD(a, b); 
  
  		
		int result = 0; 
		for (int i = 1; i <= Math.sqrt(n); i++) 
		{ 
			if (n % i == 0) 
			{ 
				// check if divisors are equal 
				if (n / i == i) 
				{
					
					result = result + 1; 
					
				}
				else
				{
					result =result + 2; 
				}
 			} 
			
	 	} 
		return result; 
	} 
  
	public static void main(String args[]) 
	{
		int a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers");
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println(commDiv(a, b)); 
	} 
} 